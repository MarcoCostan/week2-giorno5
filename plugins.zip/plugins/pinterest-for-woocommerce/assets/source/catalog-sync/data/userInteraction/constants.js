export const STORE_NAME = 'pinterest_for_woocommerce/admin/userInteraction';
export const API_ROUTE =
	wcSettings.pinterest_for_woocommerce.apiRoute + '/user_interaction';
