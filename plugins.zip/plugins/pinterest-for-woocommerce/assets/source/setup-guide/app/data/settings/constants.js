export const STORE_NAME = 'pinterest_for_woocommerce/admin/settings';
export const API_ENDPOINT =
	wcSettings.pinterest_for_woocommerce.apiRoute + '/settings';
export const OPTIONS_NAME = wcSettings.pinterest_for_woocommerce.optionsName;
