<?php
namespace MailPoetVendor\Twig\Sandbox;
if (!defined('ABSPATH')) exit;
use MailPoetVendor\Twig\Error\Error;
class SecurityError extends Error
{
}
